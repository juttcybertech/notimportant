import os, subprocess, time, uuid, requests, sqlite3
from threading import Semaphore, Thread
from flask import Flask, request, jsonify, send_file, render_template, g, send_from_directory
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from yt_dlp import YoutubeDL, DownloadError
from collections import Counter
from functools import wraps
from datetime import datetime
from dotenv import load_dotenv

# ✅ Initialize Flask app
# We're telling Flask to also look for static files in the 'templates' directory
# because admin.css is located there. The standard is a 'static' folder.
app = Flask(__name__, static_folder='templates', static_url_path='')


# ✅ Rate Limiting for security
limiter = Limiter(
    get_remote_address,
    app=app,
    # General limits for all API routes to prevent abuse
    default_limits=["200 per day", "50 per hour"],
    storage_uri="memory://"
)

# ✅ Load environment variables
load_dotenv("api.env")

# ✅ CORS Configuration from .env
# Load allowed origins from .env file, with a fallback for local development
ALLOWED_ORIGINS_STR = os.getenv("ALLOWED_ORIGINS", "http://localhost:5000,http://127.0.0.1:5000,null")
allowed_origins = [origin.strip() for origin in ALLOWED_ORIGINS_STR.split(',')]
CORS(app, origins=allowed_origins)

ADMIN_USERNAME = os.getenv("ADMIN_USERNAME")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD")

# ✅ Setup folders and database
UPLOAD_FOLDER = 'downloads'
DB_PATH = 'logs.db'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ✅ Initialize SQLite database
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS logs
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 timestamp TEXT,
                 ip TEXT,
                 action TEXT,
                 url TEXT,
                 user_agent TEXT,
                 country TEXT,
                 city TEXT,
                 isp TEXT,
                 continent TEXT,
                 timezone TEXT)''')
    # ✅ Add indexes for faster analytics queries
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_action ON logs (action);")
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs (timestamp);")
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_ip ON logs (ip);")
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_country ON logs (country);")
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_city ON logs (city);")
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_url ON logs (url);")
    conn.commit()
    conn.close()

init_db()

# ✅ Concurrency limits
MAX_USERS = 30
user_semaphore = Semaphore(MAX_USERS)

def get_ip_info(ip):
    try:
        res = requests.get(f"http://ip-api.com/json/{ip}")
        return res.json() if res.status_code == 200 else {}
    except:
        return {}

def log_user(ip, url, action, user_agent):
    ip_info = get_ip_info(ip)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("PRAGMA journal_mode=WAL;") # Enable WAL mode for better concurrency
    c.execute('''INSERT INTO logs 
                 (timestamp, ip, action, url, user_agent, country, city, isp, continent, timezone)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                 (timestamp, ip, action, url, user_agent,
                  ip_info.get('country'), ip_info.get('city'), ip_info.get('isp'),
                  ip_info.get('continent'), ip_info.get('timezone')))
    conn.commit()
    conn.close()

def schedule_deletion(file_path, delay=600):
    def delete_file():
        time.sleep(delay)
        if os.path.exists(file_path):
            os.remove(file_path)
    Thread(target=delete_file, daemon=True).start()

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({ "status": "ok", "users_available": user_semaphore._value })

@app.route('/api/preview', methods=['POST'])
def api_preview():
    if not user_semaphore.acquire(blocking=False):
        return jsonify({"error": "Server busy"}), 503
    try:
        data = request.get_json()
        url = data.get('url')
        if not url or 'tiktok.com' not in url:
            return jsonify({"error": "Invalid TikTok URL"}), 400
        ip = request.headers.get("X-Forwarded-For", request.remote_addr)
        user_agent = request.headers.get('User-Agent')
        log_user(ip, url, "preview", user_agent)
        
        info = fetch_video_info(url)
        if "error" in info:
            return jsonify(info), 400
        return jsonify(info)
    finally:
        user_semaphore.release()

@app.route('/api/download/video', methods=['POST'])
def api_download_video():
    # This is a long-running task, so we release the semaphore early
    # to allow other users to make requests while the download happens.
    # A more robust solution might use a separate worker queue.
    if not user_semaphore.acquire(blocking=False):
        return jsonify({"error": "Server busy"}), 503
    try:
        data = request.get_json()
        url = data.get('url')
        if not url or 'tiktok.com' not in url:
            return jsonify({"error": "Invalid TikTok URL"}), 400
        ip = request.headers.get("X-Forwarded-For", request.remote_addr)
        user_agent = request.headers.get('User-Agent')
        log_user(ip, url, "download_video", user_agent)
        
        try:
            file_path = download_tiktok_video(url)
            return send_file(file_path, as_attachment=True)
        except DownloadError as e:
            # Send a clear error back to the user if download fails
            error_message = str(e)
            if "This post may not be comfortable" in error_message:
                return jsonify({"error": "This video is age-restricted or private and cannot be downloaded."}), 403
            return jsonify({"error": "Failed to download video."}), 500
    finally:
        user_semaphore.release()

@app.route('/api/download/audio', methods=['POST'])
def api_download_audio():
    if not user_semaphore.acquire(blocking=False):
        return jsonify({"error": "Server busy"}), 503
    try:
        data = request.get_json()
        url = data.get('url')
        if not url or 'tiktok.com' not in url:
            return jsonify({"error": "Invalid TikTok URL"}), 400
        ip = request.headers.get("X-Forwarded-For", request.remote_addr)
        user_agent = request.headers.get('User-Agent')
        log_user(ip, url, "download_audio", user_agent)
        
        try:
            file_path = download_audio(url)
            return send_file(file_path, as_attachment=True)
        except DownloadError as e:
            error_message = str(e)
            if "This post may not be comfortable" in error_message:
                return jsonify({"error": "This video is age-restricted or private and cannot be downloaded."}), 403
            return jsonify({"error": "Failed to download audio."}), 500
    finally:
        user_semaphore.release()

# Beautiful Admin Interface
@app.route('/admin', methods=['GET', 'POST'])
def admin():
    error = None
    # --- Pagination Logic ---
    page = request.args.get('page', 1, type=int)
    LOGS_PER_PAGE = 20
    offset = (page - 1) * LOGS_PER_PAGE

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            conn = sqlite3.connect(DB_PATH)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL;") # Enable WAL mode for better concurrency
            c = conn.cursor()
            
            # --- Advanced Analytics Processing using SQL for performance ---
            
            # Total requests and unique visitors
            c.execute("SELECT COUNT(*), COUNT(DISTINCT ip) FROM logs")
            total_requests, unique_visitors = c.fetchone()
            
            # Data for Doughnut Chart (Action Breakdown)
            c.execute("SELECT action, COUNT(*) FROM logs GROUP BY action")
            action_counts = c.fetchall()
            action_labels = [row['action'].replace('_', ' ').capitalize() for row in action_counts]
            action_data = [row[1] for row in action_counts]
            
            # Data for Bar Chart (Top 5 Countries)
            c.execute("SELECT country, COUNT(*) as count FROM logs WHERE country IS NOT NULL GROUP BY country ORDER BY count DESC LIMIT 5")
            country_counts = c.fetchall()
            country_labels = [row['country'] for row in country_counts]
            country_data = [row['count'] for row in country_counts]
            
            # Data for Bar Chart (Top 5 Cities)
            c.execute("SELECT city, COUNT(*) as count FROM logs WHERE city IS NOT NULL GROUP BY city ORDER BY count DESC LIMIT 5")
            city_counts = c.fetchall()
            city_labels = [row['city'] for row in city_counts]
            city_data = [row['count'] for row in city_counts]
            
            # Data for Line Chart (Requests over the last 15 days)
            # Note: The date function is specific to SQLite
            c.execute("SELECT date(timestamp) as day, COUNT(*) as count FROM logs WHERE date(timestamp) >= date('now', '-15 days') GROUP BY day ORDER BY day ASC")
            daily_requests = c.fetchall()
            time_labels = [row['day'] for row in daily_requests]
            time_data = [row['count'] for row in daily_requests]
            
            # Data for Bar Chart (Top 5 User Agents)
            c.execute("SELECT user_agent, COUNT(*) as count FROM logs WHERE user_agent IS NOT NULL GROUP BY user_agent ORDER BY count DESC LIMIT 5")
            user_agent_counts = c.fetchall()
            # Shorten long user agents for better display
            user_agent_labels = [ (agent[:40] + '...') if len(agent) > 40 else agent for agent in [row['user_agent'] for row in user_agent_counts] ]
            user_agent_data = [row['count'] for row in user_agent_counts]

            # Data for Bar Chart (Top 5 URLs) - only counting downloads
            c.execute("SELECT url, COUNT(*) as count FROM logs WHERE url IS NOT NULL AND (action = 'download_video' OR action = 'download_audio') GROUP BY url ORDER BY count DESC LIMIT 5")
            url_counts = c.fetchall()
            url_labels = [row['url'] for row in url_counts]
            url_data = [row['count'] for row in url_counts]

            # Data for Radar Chart (Activity by Hour) - strftime('%H',...) is SQLite specific
            c.execute("SELECT strftime('%H', timestamp) as hour, COUNT(*) as count FROM logs GROUP BY hour ORDER BY hour ASC")
            hourly_counts_raw = c.fetchall()
            hourly_dict = {row['hour']: row['count'] for row in hourly_counts_raw}
            hourly_labels = [f"{h:02d}:00" for h in range(24)]
            hourly_data = [hourly_dict.get(f"{h:02d}", 0) for h in range(24)]
            
            analytics = {
                'total_requests': total_requests or 0,
                'unique_visitors': unique_visitors or 0,
                'charts': {
                    'actions': {'labels': action_labels, 'data': action_data},
                    'countries': {'labels': country_labels, 'data': country_data},
                    'cities': {'labels': city_labels, 'data': city_data},
                    'timeline': {'labels': time_labels, 'data': time_data},
                    'user_agents': {'labels': user_agent_labels, 'data': user_agent_data},
                    'top_urls': {'labels': url_labels, 'data': url_data},
                    'by_hour': {'labels': hourly_labels, 'data': hourly_data}
                }
            }

            # Fetch total log count for pagination
            c.execute("SELECT COUNT(id) FROM logs")
            total_logs = c.fetchone()[0]
            total_pages = (total_logs + LOGS_PER_PAGE - 1) // LOGS_PER_PAGE

            # Fetch the paginated logs
            c.execute("SELECT * FROM logs ORDER BY id DESC LIMIT ? OFFSET ?", (LOGS_PER_PAGE, offset))
            logs = c.fetchall()
            conn.close()

            return render_template('admin.html', logs=logs, analytics=analytics, 
                                   current_page=page, total_pages=total_pages)
        else:
            error = "Invalid username or password."

    return render_template('login.html', error=error)

@app.errorhandler(429)
def ratelimit_handler(e):
    """Custom handler for rate limit exceeded errors."""
    # For API routes, return a JSON error
    return jsonify(error=f"ratelimit exceeded: {e.description}"), 429

def download_tiktok_video(url):
    unique_id = str(uuid.uuid4())[:8]
    ydl_opts = {
        'format': 'bestvideo[height<=720][ext=mp4]+bestaudio/best',
        'outtmpl': os.path.join(UPLOAD_FOLDER, f'%(title)s_{unique_id}.%(ext)s'),
        'quiet': True,
    }
    try:
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            file_path = ydl.prepare_filename(info)
            schedule_deletion(file_path)
            return file_path
    except DownloadError as e:
        # Re-raise the exception to be handled by the API endpoint
        raise e

def download_audio(url):
    unique_id = str(uuid.uuid4())[:8]
    ydl_opts = {
        'format': 'bestaudio/best',
        'outtmpl': os.path.join(UPLOAD_FOLDER, f'%(title)s_{unique_id}.%(ext)s'),
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'quiet': True,
    }
    try:
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            # The final path will have the .mp3 extension due to the postprocessor
            base_path = os.path.splitext(ydl.prepare_filename(info))[0]
            final_path = base_path + '.mp3'
            
            # Ensure the file exists before scheduling deletion, as yt-dlp might fail after download but before conversion
            if os.path.exists(final_path):
                schedule_deletion(final_path)
                return final_path
            raise DownloadError("Audio conversion failed.")
    except DownloadError as e:
        raise e

def fetch_video_info(url):
    ydl_opts = { 'quiet': True, 'skip_download': True }
    try:
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            return {
                'title': info.get('title'),
                'author': info.get('uploader'),
                'thumbnail': info.get('thumbnail'),
                'duration': info.get('duration'),
                'views': info.get('view_count'),
                'likes': info.get('like_count'),
                'webpage_url': info.get('webpage_url')
            }
    except DownloadError as e:
        error_message = str(e)
        if "This post may not be comfortable" in error_message:
            return {"error": "This video is age-restricted or private and cannot be previewed."}
        return {"error": "Could not fetch video details. The URL might be invalid or the video removed."}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)